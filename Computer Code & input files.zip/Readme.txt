This is the code of the subroutine of Duncan-Chang model compiled in Fortran language.
The file, Initialstress.inp and Stablepile.inp are the input file to numerically compute the pilot pile.
If you have any questions, please contact me via Email:dzhang@fzu.edu.cn or Cell phone:+86 13625098017.